<div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gray-100">
    

    <div class="w-full sm:max-w-md mt-6 px-6 py-4 bg-white shadow-md sm:rounded-lg">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/components/authentication-card.blade.php ENDPATH**/ ?>