<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row mt-5">
            <h4><?php echo e($hall->name); ?></h4>

            <?php $__currentLoopData = $cartItem['services_ids']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $serviceId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p>الخدمة <?php echo e($services[$index]->name); ?></p>
                <p>السعر <?php echo e($cartItem['price'][$index]); ?></p>
                <p>الكمية <?php echo e($cartItem['quantity'][$index]); ?></p>
                <p>الاجمالي <?php echo e($cartItem['price'][$index] * $cartItem['quantity'][$index]); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div>
                <a href="<?php echo e(route('cart.edit',$hall->id)); ?>">تعديل</a>
                <a href="<?php echo e(route('cart.index')); ?>">العودة للقائمة</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/cart/details.blade.php ENDPATH**/ ?>