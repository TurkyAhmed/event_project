<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <?php if($mailData['flag']=='aprroved'): ?>
        <h1><?php echo e($mailData['user']); ?></h1>
        <h3><?php echo e($mailData['title']); ?></h3>
        <p><?php echo e($mailData['body']); ?></p>
        <p>دمتم بودٍ</p>
    <?php endif; ?>
</body>
</html>
<?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/mails/reservation_approves.blade.php ENDPATH**/ ?>