<?php $__env->startSection('dashboard-content'); ?>

    <div class="container pt-5 pe-5">
        <h2 class="pb-4"> قائمة القاعات </h2>
        <a class="btn btn-outline-primary my-bg-grad mb-3" href="<?php echo e(route('halls.create')); ?>"> إضافة قاعة  </a>
        <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col"> الاسم  </th>
                <th scope="col"> السعر </th>
                <th scope="col"> الإجراءات </th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $halls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <tr>
                    <th scope="row">1</th>
                    <td><?php echo e($hall->name); ?> </td>
                    <td><?php echo e($hall->price); ?></td>
                    <td>
                        <a class="  " href="<?php echo e(route('halls.show',$hall->id)); ?>"> <i class="fa-solid fa-circle-info"></i> |</a>
                        <a class=" " href="<?php echo e(route('halls.edit',$hall->id)); ?>"> <i class="fa-solid fa-pen-to-square"></i> |</a>
                        <a class=" " href="<?php echo e(route('halls.delete',$hall->id)); ?>"> <i class="fa-solid fa-trash"></i> </a>
                    </td>
                  </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

        <div class="pagination">
            <ul class="pagination justify-content-center">
                <?php if($halls->onFirstPage()): ?>
                    <li class="page-item disabled">
                        <span class="page-link">&laquo;</span>
                    </li>
                <?php else: ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($halls->previousPageUrl()); ?>" rel="prev">&laquo;</a>
                    </li>
                <?php endif; ?>
                <?php $__currentLoopData = $halls->getUrlRange(1, $halls->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="page-item <?php echo e($page == $halls->currentPage() ? 'active' : ''); ?>">
                        <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($halls->hasMorePages()): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($halls->nextPageUrl()); ?>" rel="next">&raquo;</a>
                    </li>
                <?php else: ?>
                    <li class="page-item disabled">
                        <span class="page-link">&raquo;</span>
                    </li>
                <?php endif; ?>
            </ul>
        </div>

        <!-- Pagination label -->
        <div class="pagination-label">
            Page <?php echo e($halls->currentPage()); ?> of <?php echo e($halls->lastPage()); ?>

        </div>

    </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/halls/index.blade.php ENDPATH**/ ?>