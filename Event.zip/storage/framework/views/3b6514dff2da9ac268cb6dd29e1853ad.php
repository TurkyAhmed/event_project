<?php $__env->startSection('dashboard-content'); ?>

<div class="container pt-5 pe-5">
    <h2 class="pb-4"> قائمة الحجوزات </h2>
    <a class="btn btn-outline-primary my-bg-grad mb-3" href="<?php echo e(route('reservations.create')); ?>"> إضافة حجز  </a>
    <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col"> عنوان الحجز  </th>
            <th scope="col">  الجهةالحاجزة </th>
            <th scope="col">  الحالة </th>
            <th scope="col">  من تاريخ </th>
            <th scope="col">  إلى تاريخ </th>
            <th scope="col"> الإجراءات </th>
          </tr>
        </thead>
        <tbody>
            <?php
                $counter = 1 ;
            ?>
            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservaion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <th scope="row"><?php echo e($counter); ?></th>
                <td><?php echo e($reservaion->title); ?> </td>
                <td><?php echo e($reservaion->user_id); ?></td>
                <td><?php echo e($reservaion->status); ?></td>
                <td><?php echo e($reservaion->date_from); ?></td>
                <td><?php echo e($reservaion->date_to); ?></td>
                <td>
                    <a class=" btn btn-primary " href="<?php echo e(route('reservations.reservationApproved',$reservaion->id)); ?>"> تأكيد الحجز </a>
                    <a class=" btn btn-secondary " href="<?php echo e(route('reservations.reservationcancelled',$reservaion->id)); ?>"> الغاء الحجز </a>

                </td>
              </tr>

            <?php
              $counter++ ;
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/reservations/reservation_waiting.blade.php ENDPATH**/ ?>