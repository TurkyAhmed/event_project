<?php $__env->startSection('dashboard-content'); ?>

    <div class="container pt-5 pe-5">
        <h2 class="pb-4"> قائمة الخدمات </h2>
        <a class="btn btn-outline-primary my-bg-grad mb-3" href="<?php echo e(route('services.create')); ?>"> إضافة خدمة  </a>
                <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col"> اسم الخدمة  </th>
                <th scope="col"> سعر الخدمة </th>
                <th scope="col"> الإجراءات </th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <tr>
                    <th scope="row">1</th>
                    <td><?php echo e($service->name); ?> </td>
                    <td><?php echo e($service->price); ?></td>
                    <td>
                        <a href="<?php echo e(route('services.show',$service->id)); ?>"> <i class="fa-solid fa-circle-info"></i>  |</a>
                        <a href="<?php echo e(route('services.edit',$service->id)); ?>"> <i class="fa-solid fa-pen-to-square"></i> | </a>
                        <a href="<?php echo e(route('services.delete',$service->id)); ?>"> <i class="fa-solid fa-trash"></i> </a>
                    </td>
                  </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/services/index.blade.php ENDPATH**/ ?>