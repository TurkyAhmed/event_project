<?php $__env->startSection('filtered_reservations'); ?>

<table class="table">
    <thead>
        <tr>
            <th>Title</th>
            <th>Interval</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $reservationas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($reservation->title); ?></td>
            <td><?php echo e($reservation->interval); ?></td>
            <td><?php echo e($reservation->status); ?></td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('reservations.reports', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/reservations/partialview/filtered_reservations.blade.php ENDPATH**/ ?>