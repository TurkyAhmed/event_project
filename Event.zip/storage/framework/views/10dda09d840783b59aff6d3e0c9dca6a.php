<?php $__env->startSection('dashboard-content'); ?>

    <style>
        #calendar{
            height: calc(100vh - 5rem);
        }
        .bg-gradient-danger{
            color: #fff;
            background-image: linear-gradient(45deg,#6eabc2,#506c6a);
        }
    </style>


    <div class="card card-calendar">
        <div class="card-body p-3">
          <div class="calendar" data-bs-toggle="calendar" id="calendar"></div>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/js/index.global.js')); ?>"></script>
    <script>
        var reservation_from_database = <?php echo json_encode($reservations, 15, 512) ?>;
    </script>
    <script src="<?php echo e(asset('assets/js/calender.js')); ?>"></script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/reservations/calender.blade.php ENDPATH**/ ?>