<?php $__env->startSection('content'); ?>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <?php $__currentLoopData = $halls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 col-lg-4 mt-3">
                    <div class="card_shadow">
                        <h3><?php echo e($hall->name); ?></h3>
                        <div class="d-flex">
                            <p class="w-50"><a href="<?php echo e(route('cart.show',$hall->id)); ?>" class="" >تفاصيل</a></p>
                            <p class="w-50"><a href="<?php echo e(route('cart.cancelSpecificreservation',$hall->id)); ?>" class="" > الغاء </a></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/cart/index.blade.php ENDPATH**/ ?>