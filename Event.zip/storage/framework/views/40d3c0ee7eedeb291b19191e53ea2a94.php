<?php $__env->startSection('dashboard-content'); ?>

<div class="container py-5 pe-5 my-bg-img">

    <div class="form-fram">
        <div class="sub-header-page mb-3">
            <h3 class="text-center"> الخدمات </h3>
        </div>

        <form action="<?php echo e(route('services.edit',$service->id)); ?>" method="">
            <?php echo csrf_field(); ?>
            <div class="card">
            <div class="card-header">
              تفاصيل الخدمة
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <label for="name" class="form-label"> اسم الخدمة </label>
                    <p class="d-inline-block"><?php echo e($service->name); ?></p>
                  </div>

                <div class="mb-3">
                    <label for="price" class="form-label"> سعر الخدمة</label>
                    <p class="d-inline-block"><?php echo e($service->price); ?></p>
                </div>

                <div class="mb-3">
                    <label for="feature" class="form-label"> نوع الخدمة : </label>
                    <p class="d-inline-block"><?php echo e($service->is_main_service? 'خدمة اساسية' : ' خدمة فرعية '); ?></p>
                </div>

                <div class="mb-3">
                    <label for="price" class="form-label"> حالة الخدمة :</label>
                    <p class="d-inline-block"><?php echo e($service->status ? 'نشط' : 'غير نشط'); ?></p>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label"> وصف الخدمة :</label>
                    <p class="d-inline-block"><?php echo e($service->description); ?></p>
                </div>

                <div class="btn-group d-flex gap-4">
                    <button class="btn btn-primary my-bg-grad w-50" type="submit"> تعديل </button>
                    <a class="btn btn-outline-primary my-bg-transparent bg-tr w-50" href="<?php echo e(route('services.index')); ?>">تراجع</a>
              </div>

            </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/services/details.blade.php ENDPATH**/ ?>