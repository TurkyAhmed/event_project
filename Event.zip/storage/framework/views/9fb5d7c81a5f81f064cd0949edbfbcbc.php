<?php $__env->startSection('content'); ?>
    <div class="container pt-5">

        <h1> كل الخدمات المحذوفة </h1>
        <table class="table table-dark table-striped mt-2">
            <div class="container pt-5">
                <a class="btn btn-primary" href="<?php echo e(route('services.create')); ?>"> إضافة خدمة </a>
                <table class="table table-striped">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col"> اسم الخدمة  </th>
                        <th scope="col"> السعر </th>
                        <th scope="col"> الإجراءات </th>
                      </tr>
                    </thead>
            <tbody>
                <?php $__currentLoopData = $Services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                  <th scope="row">1</th>
                  <td><?php echo e($Service->name); ?> </td>
                  <td><?php echo e($Service->price); ?></td>
                    <td>
                        
                        <a class="btn btn-primary" href="<?php echo e(route('services.restore',$Service->id)); ?>"> Restore</a>
                        <form action="<?php echo e(route('services.forcedelete',$Service->id)); ?>" method="get" class="d-inline-block">
                            <?php echo csrf_field(); ?>
                            
                            <button type="submit" class="btn btn-danger">Force Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>


    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/Services/ServicesSoftDelete.blade.php ENDPATH**/ ?>