<?php $__env->startSection('dashboard-content'); ?>

    <div class="container pt-5 pe-5">
        <h2 class="pb-4"> قائمة المستخدمين </h2>
        <?php if(auth()->user()->role_id !=2): ?>
            <a class="btn btn-outline-primary my-bg-grad mb-3" href="<?php echo e(route('users.create')); ?>"> إضافة مستخدم  </a>
        <?php endif; ?>
        <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col"> اسم المستخدم  </th>
                <th scope="col">  البريد الالكتروني  </th>
                <th scope="col"> الإجراءات </th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <tr>
                    <th scope="row">1</th>
                    <td><?php echo e($user->name); ?> </td>
                    <td><?php echo e($user->email); ?></td>
                    <td>
                        <a href="<?php echo e(route('users.show',$user->id)); ?>"> <i class="fa-solid fa-circle-info"></i>  |</a>
                        <a href="<?php echo e(route('users.edit',$user->id)); ?>"> <i class="fa-solid fa-pen-to-square"></i> | </a>
                        <a href="<?php echo e(route('users.delete',$user->id)); ?>"> <i class="fa-solid fa-trash"></i> </a>
                    </td>
                  </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

        <!-- this for laravel-->
        

        <!-- this for customized pagination links with bootstrap -->
        <div class="pagination">
            <ul class="pagination justify-content-center">
                <?php if($users->onFirstPage()): ?>
                    <li class="page-item disabled">
                        <span class="page-link">&laquo;</span>
                    </li>
                <?php else: ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($users->previousPageUrl()); ?>" rel="prev">&laquo;</a>
                    </li>
                <?php endif; ?>
                <?php $__currentLoopData = $users->getUrlRange(1, $users->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="page-item <?php echo e($page == $users->currentPage() ? 'active' : ''); ?>">
                        <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($users->hasMorePages()): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($users->nextPageUrl()); ?>" rel="next">&raquo;</a>
                    </li>
                <?php else: ?>
                    <li class="page-item disabled">
                        <span class="page-link">&raquo;</span>
                    </li>
                <?php endif; ?>
            </ul>
        </div>

        <!-- Pagination label -->
        <div class="pagination-label">
            Page <?php echo e($users->currentPage()); ?> of <?php echo e($users->lastPage()); ?>

        </div>


    </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/users/index.blade.php ENDPATH**/ ?>