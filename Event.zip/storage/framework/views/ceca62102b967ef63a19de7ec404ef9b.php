<?php $__env->startSection('dashboard-content'); ?>

<div class="container pt-5 pe-5">
    <form action="<?php echo e(route('users.destroy',$user->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <h4> حذف المستخدم </h4>
        <h6 class="mb-4"> هل تريد فعلاً حذف هذا المستخدم  </h6>

        <div class="mb-3">
            <label for="name" class="form-label"> اسم المستخدم </label>
            <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>" id="name" placeholder="اسم المستخدم">
          </div>

          <div class="mb-3">
            <label for="phone" class="form-label"> رقم المستخدم</label>
            <input type="text" name="phone" class="form-control" value="<?php echo e($user->phone); ?>" id="phone" placeholder=" رقم المستخدم ">
          </div>

          <div class="mb-3">
            <label for="email" class="form-label"> البريد الالكتروني </label>
            <input type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>" id="email" placeholder=" البريد الالكتروني  ">
        </div>


        <div class="btn-group d-flex gap-4">
            <button class="btn btn-danger w-50" type="submit"> تأكيد الحذف  </button>
            <a class="btn btn-outline-primary my-bg-transparent bg-tr w-50" href="<?php echo e(route('users.index')); ?>">تراجع</a>
        </div>

    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/users/delete.blade.php ENDPATH**/ ?>