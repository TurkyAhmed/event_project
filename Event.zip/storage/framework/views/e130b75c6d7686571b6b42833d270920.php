<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-..." crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    
    

    <title>Document</title>
    <style>
        .bg-gradient-danger{
            background-color: yellow;
        }
    </style>
</head>
<body>
    

    <div class="card card-calendar">
        <div class="card-body p-3">
          <div class="calendar" data-bs-toggle="calendar" id="calendar"></div>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/js/index.global.js')); ?>"></script>
    <script>

        // document.addEventListener('DOMContentLoaded', function() {
        //   var calendarEl = document.getElementById('calendar');

        //   var calendar = new FullCalendar.Calendar(calendarEl, {
        //     initialView: 'dayGridMonth',
        //     selectable: true,
        //     editable: true
        //   });
        //   calendar.render();
        // });

    var reservation_from_database = <?php echo json_encode($reservations, 15, 512) ?>;
    console.log(reservation_from_database);

    var calendar = new FullCalendar.Calendar(document.getElementById("calendar"), {

    // initialView: 'multiMonthFourMonth',
    initialView: "dayGridMonth",
    headerToolbar: {
        left: 'prev,next today', // will normally be on the left. if RTL, will be on the right
        center: 'title',
        right: 'month,agendaWeek,agendaDay,listMonth' // will normally be on the right. if RTL, will be on the left
    },
    selectable: true,
    editable: true,
    initialDate: new Date(),
    // initialDate: '2020-12-01',
    events: reservation_from_database
  ,
    views: {
      month: {
        titleFormat: {
          month: "long",
          year: "numeric"
        }
      },
      agendaWeek: {
        titleFormat: {
          month: "long",
          year: "numeric",
          day: "numeric"
        }
      },
      agendaDay: {
        titleFormat: {
          month: "short",
          year: "numeric",
          day: "numeric"
        }
      },
      multiMonthFourMonth: {
      type: 'multiMonth',
      duration: { months: 12 }
    }
    },
    });

    calendar.render();

    </script>
</body>
</html>
<?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/calender.blade.php ENDPATH**/ ?>