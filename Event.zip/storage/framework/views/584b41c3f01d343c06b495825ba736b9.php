<?php $__env->startSection('content'); ?>

    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="<?php echo e(asset('assets/imgs/istdama.jpg')); ?>" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="<?php echo e(asset('assets/imgs/slam.jpg')); ?>" class="d-block w-100" alt="...">
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
    </div>

    <div class="container pt-5 mt-5">
        <div class="row">
            <h1 class="mb-5"> <?php echo e($hall->name); ?></h1>

            <?php
                $descriptions = explode('|',$hall->description);
            ?>
            <h4 class=""> سعة القاعة : </h4>
            <?php if($descriptions[0] != null): ?>
                <p class="fs-5 pe-5"> تتسع القاعة للـ <?php echo e($hall->capacity); ?> شخص , ولكن قد تختلف سعتها على حسب نظام ترتيب الطاولات وسيكون سعتها موضحا بالشكل التالي :</p>
                <div class="row mb-5">
                    <?php $__currentLoopData = $descriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $description): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12 col-md-6 col-lg-4 mb-3">
                            <div class="card_shadow card_hover">
                              <p class="pe-2 pt-2 fs-5"> <?php echo e($description); ?> </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
            <p class="fs-5 pe-5 mb-5"> تتسع القاعة للـ <?php echo e($hall->capacity); ?> شخص. </p>
            <?php endif; ?>


            <?php
                $features = explode('|',$hall->feature);
            ?>
            <h4> مميزات القاعة :</h4>
            <div class="row mb-5">
                <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                      
                          <?php if(str_contains($feature,'مساحة')): ?>
                              <div class="col-12 col-md-4 ">
                                  <div class="card_shadow card_hover d-flex mb-3">
                                      <i class="fa-solid fa-ruler-combined "></i>
                                      <p class="pe-4 fs-5"> <?php echo e($feature); ?></p>
                                  </div>
                                </div>
                          <?php elseif(str_contains($feature,'إمكانية')): ?>
                              <div class="col-12 col-md-4 ">
                                  <div class="card_shadow card_hover d-flex mb-3">
                                      <p  class="pe-4 fs-5"><?php echo e($feature); ?></p>
                                  </div>
                              </div>
                          <?php elseif(str_contains($feature,'مكيفة')): ?>
                              <div class="col-12 col-md-4 ">
                                  <div class="card_shadow card_hover d-flex mb-3">
                                      <i class="fa-regular fa-snowflake"></i>
                                      <p class="pe-4 fs-5"> <?php echo e($feature); ?> </p>
                                  </div>
                              </div>
                          <?php elseif(str_contains($feature,'إنترنت')): ?>
                              <div class="col-12 col-md-4 ">
                                  <div class="card_shadow card_hover d-flex mb-3">
                                      <p class="pe-4 fs-5"><i class="fa-solid fa-wifi"></i> <?php echo e($feature); ?> </p>
                                  </div>
                              </div>
                          <?php elseif(str_contains($feature,'شاشة ')): ?>
                              <div class="col-12 col-md-4 ">
                                  <div class="card_shadow card_hover d-flex mb-3">
                                      <i class="fa-solid fa-tv"></i>
                                      <p class="pe-4 fs-5"> <?php echo e($feature); ?> </p>
                                  </div>
                              </div>
                          <?php elseif(str_contains($feature,'ستاند')): ?>
                              <div class="col-12 col-md-4 ">
                                  <div class="card_shadow card_hover d-flex mb-3">
                                      <img src="<?php echo e(asset('assets/imgs/stand.svg')); ?>" target="icon_size" alt="">
                                      <p class="pe-4 fs-5"><?php echo e($feature); ?> </p>
                                  </div>
                                </div>
                          <?php elseif(str_contains($feature,'الياف')): ?>
                              <div class="col-12 col-md-4 ">
                                  <div class="card_shadow card_hover d-flex mb-3">
                                      <img src="<?php echo e(asset('assets/imgs/sticky_notes_icon.svg')); ?>" target="icon_size" alt="">
                                      <p class="pe-4 fs-5"><?php echo e($feature); ?> </p>
                                  </div>
                              </div>
                          <?php endif; ?>
                      
                  

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <h4> سعر القاعة :</h4>
            <p class="pe-4 fs-5">سعر القاعة للحجز الواحد  <strong><?php echo e($hall->price); ?><span target="dolar">$</span></strong> </p>
            <?php if($hall->discount != 0): ?>
                <h5 class="mt-3">خصم القاعة :</h5>
                <p class="pe-4 fs-5"> الخصم <strong><?php echo e($hall->discount); ?><span target="dolar">$</span></strong> </p>
                <p class="pe-4 fs-5"> السعر السابق <del><?php echo e($hall->price); ?></del><span target="dolar">$</span> السعر الحالي <ins><?php echo e($hall->price - $hall->discount); ?></ins><span target="dolar">$</span> </p>
            <?php endif; ?>


            

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/halls/landingpage_hall_details.blade.php ENDPATH**/ ?>