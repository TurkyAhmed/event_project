<?php $__env->startSection('content'); ?>

<div class="container">
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/publicViews/roomdetials.blade.php ENDPATH**/ ?>