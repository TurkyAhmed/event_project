<?php $__env->startSection('dashboard-content'); ?>

<div class="container py-5 pe-5 my-bg-img">

    <div class="form-fram">
        <div class="sub-header-page mb-3">
            <h3 class="text-center">  القاعات </h3>
        </div>

      <form action="<?php echo e(route('halls.edit',$hall->id)); ?>" method="">
        <?php echo csrf_field(); ?>

        <div class="card">
            <div class="card-header">
              تفاصيل القاعة
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <label for="name" class="form-label"> اسم القاعة :</label>
                    <p class="d-inline-block"><?php echo e($hall->name); ?></p>
                  </div>

                <div class="mb-3">
                    <label for="capacity" class="form-label"> سعة القاعة :</label>
                    <p class="d-inline-block"><?php echo e($hall->capacity); ?></p>
                </div>

                <div class="mb-3">
                    <label for="feature" class="form-label"> مميزات القاعة :</label>
                    <p class="d-inline-block"><?php echo e($hall->feature); ?></p>
                </div>

                <div class="mb-3">
                    <label for="price" class="form-label"> سعر القاعة</label>
                    <p class="d-inline-block"><?php echo e($hall->price); ?></p>
                </div>

                <div class="mb-3">
                    <label for="discount" class="form-label"> خصم القاعة :</label>
                    <p class="d-inline-block"><?php echo e($hall->discount); ?></p>
                </div>

                <div class="mb-3">
                    <label for="price" class="form-label"> حالة القاعة :</label>
                    <p class="d-inline-block"><?php echo e($hall->status ? 'نشط' : 'غير نشط'); ?></p>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label"> وصف القاعة :</label>
                    <p class="d-inline-block"><?php echo e($hall->description); ?></p>
                </div>

                <div class="mb-3">
                    <label for="discount" class="form-label"> خصم القاعة :</label>
                    <p class="d-inline-block"><?php echo e($hall->discount); ?></p>
                </div>

                <div class="btn-group d-flex gap-4">
                    <button class="btn btn-primary my-bg-grad w-50" type="submit"> تعديل </button>
                    <a class="btn btn-outline-primary my-bg-transparent bg-tr w-50" href="<?php echo e(route('halls.index')); ?>">تراجع</a>
                </div>

            </div>
        </div>

      </form>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/halls/details.blade.php ENDPATH**/ ?>