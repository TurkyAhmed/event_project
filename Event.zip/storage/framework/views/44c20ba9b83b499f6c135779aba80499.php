<?php $__env->startSection('dashboard-content'); ?>

    <div class="container py-5 pe-5">
        <div class="reservation_filter bg-light px-4 py-3">
        <div class="row">
            <div class="col-10 col-md-4">
                <div class="mb-3">
                    <label for="interval">القاعة</label>
                    <select class="form-control" id="hall" name="hall_id">
                        <option selected disabled >--اختار القاعة--</option>
                        <?php $__currentLoopData = $halls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($hall->id); ?>" ><?php echo e($hall->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="col-10 col-md-4">
                <div class="mb-3">
                    <label for="date_from" class="form-label">  من تاريخ </label>
                    <input type="date" name="date_from" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" id="date_from" >
                    <?php $__errorArgs = ['date_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger fs-6"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="col-10 col-md-4">
                <div class="mb-3">
                    <label for="date_to" class="form-label">  الى تاريخ </label>
                    <input type="date" name="date_to" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" id="date_to" >
                    <?php $__errorArgs = ['date_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger fs-6"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        </div>

        <table class="table container">
            <thead>
                <tr>
                    <th>العنوان</th>
                    <th>الفترة</th>
                    <th>الحالة</th>
                </tr>
            </thead>
            <tbody  id="reservations_filtered">
            </tbody>
        </table>
    </div>


    <script>
        $(document).ready(function() {
            console.log('page loaded');

            function updateReservations() {

                console.log('in function')

                let hallId = $('#hall').val();
                let dateFrom = $('#date_from').val();
                let dateTo = $('#date_to').val();

                console.log(`hall -> ${hallId} , and date_from -> ${dateFrom} , and date_to -> ${dateTo}`);

                $.ajax({
                    type: 'GET',
                    url: '/reservations/filter',
                    data: {
                        hall_id: hallId,
                        date_from: dateFrom,
                        date_to: dateTo
                    },
                    success: function(response) {
                        console.log(response.filteredReservations);

                        $('#reservations_filtered').html('');
                        response.filteredReservations.forEach(filteredReservation => {
                              $('#reservations_filtered').append(`
                            <tr>
                                <td> ${filteredReservation.title }</td>
                                <td> ${filteredReservation.interval == "morning"? "صباح" : "مساء"}</td>
                                <td> ${filteredReservation.status }</td>
                            </tr>`
                            );
                        });


                    },
                    error: function(xhr, status, error) {
                        console.log(error);
                        console.error(error);
                    }
                });
            }

            $('#hall, #date_from, #date_to').on('change', function() {
                console.log('change');
                updateReservations();
            });
        });
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/reservations/reports.blade.php ENDPATH**/ ?>