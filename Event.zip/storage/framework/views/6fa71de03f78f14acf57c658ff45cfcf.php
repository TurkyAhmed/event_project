<?php $__env->startSection('dashboard-content'); ?>

    <div class="container pt-5 pe-5">

        <h1> كل القاعات المحذوفة </h1>

        <table class="table table-dark table-striped mt-2">
            <div class="container pt-5">
                <a class="btn btn-primary" href="<?php echo e(route('halls.create')); ?>"> إضافة قاعة </a>
                <table class="table table-striped">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col"> الاسم  </th>
                        <th scope="col"> السعر </th>
                        <th scope="col"> الإجراءات </th>
                      </tr>
                    </thead>
            <tbody>
                <?php $__currentLoopData = $halls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                  <th scope="row">1</th>
                  <td><?php echo e($hall->name); ?> </td>
                  <td><?php echo e($hall->price); ?></td>
                    <td>
                        
                        <a class="btn btn-primary" href="<?php echo e(route('halls.restore',$hall->id)); ?>"> Restore</a>
                        <form action="<?php echo e(route('halls.forcedelete',$hall->id)); ?>" method="get" class="d-inline-block">
                            <?php echo csrf_field(); ?>
                            
                            <button type="submit" class="btn btn-danger">Force Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>


    <?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBootCamp\LaravelProjects\Event\resources\views/halls/hallsSoftDelete.blade.php ENDPATH**/ ?>